**To delete a VPC**

This example deletes the specified VPC. If the command succeeds, no output is returned.

Command::

  aws ec2 delete-vpc --vpc-id vpc-a01106c2
