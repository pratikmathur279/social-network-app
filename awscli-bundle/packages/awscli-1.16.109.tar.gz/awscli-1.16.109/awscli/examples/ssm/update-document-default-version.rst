**To update the default version of a Document**

This updates the default version of a document. There is no output if the command succeeds.

Command::

  aws ssm update-document-default-version --name "patchWindowsAmi" --document-version "2"
